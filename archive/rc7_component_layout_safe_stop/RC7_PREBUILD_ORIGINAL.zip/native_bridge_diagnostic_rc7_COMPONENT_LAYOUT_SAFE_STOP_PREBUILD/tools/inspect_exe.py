"""Read-only PE verifier for the current BSC diagnostic native mapping.

Parses the core guards[] array dynamically (no hard-coded hook count) and the
independent optional smart_guard_guard. It never loads or modifies the EXE.
"""
from __future__ import annotations
import argparse, hashlib, json, mmap, re, struct
from pathlib import Path
from typing import Any

TOKENS = ('number_of_men_alive','initial_number_of_men','is_in_melee',
          'current_target','unit_distance','position','is_moving','is_idle','ordered_width')

class PE:
    def __init__(self, data: Any):
        self.data=data
        def need(o:int,n:int)->None:
            if o<0 or n<0 or o+n>len(data): raise ValueError('truncated PE')
        need(0,64)
        if data[:2]!=b'MZ': raise ValueError('not MZ')
        off=struct.unpack_from('<I',data,0x3c)[0];need(off,24)
        if data[off:off+4]!=b'PE\0\0': raise ValueError('not PE')
        machine,count,timestamp,_,_,opt_size,_=struct.unpack_from('<HHIIIHH',data,off+4)
        if machine!=0x8664 or not 1<=count<=96: raise ValueError('requires x64 PE with sane sections')
        opt=off+24;need(opt,opt_size)
        if opt_size<112 or struct.unpack_from('<H',data,opt)[0]!=0x20b: raise ValueError('requires PE32+')
        self.image_base=struct.unpack_from('<Q',data,opt+24)[0]
        self.image_size=struct.unpack_from('<I',data,opt+56)[0]
        self.headers_size=struct.unpack_from('<I',data,opt+60)[0]
        self.timestamp=timestamp;self.sections=[]
        need(opt+opt_size,count*40)
        for i in range(count):
            o=opt+opt_size+i*40;name=data[o:o+8].split(b'\0')[0].decode('ascii','replace')
            vs,va,rs,rp=struct.unpack_from('<IIII',data,o+8);flags=struct.unpack_from('<I',data,o+36)[0]
            need(rp,rs);self.sections.append(dict(name=name,rva=va,virtual_size=vs,raw_size=rs,raw_offset=rp,flags=flags))
    def file_to_rva(self,off:int)->int|None:
        if 0<=off<min(self.headers_size,len(self.data)): return off
        for s in self.sections:
            if s['raw_offset']<=off<s['raw_offset']+s['raw_size']: return s['rva']+off-s['raw_offset']
        return None
    def rva_to_file(self,rva:int,size:int=1)->int|None:
        if 0<=rva and rva+size<=min(self.headers_size,len(self.data)): return rva
        for s in self.sections:
            if s['rva']<=rva and rva+size<=s['rva']+s['raw_size']: return s['raw_offset']+rva-s['rva']
        return None
    def section_for_rva(self,rva:int)->dict|None:
        for s in self.sections:
            span=max(s['virtual_size'],s['raw_size'])
            if s['rva']<=rva<s['rva']+span: return s
        return None
    def occurrences(self,token:str,cap:int=64)->list[dict]:
        rows=[]
        for enc in ('ascii','utf-16le'):
            needle=token.encode(enc)+(b'\0' if enc=='ascii' else b'\0\0');start=0
            while len(rows)<cap:
                off=self.data.find(needle,start)
                if off<0: break
                start=off+len(needle);rva=self.file_to_rva(off)
                if rva is not None: rows.append(dict(token=token,encoding=enc,file_offset=hex(off),rva=hex(rva)))
        return rows

def parse_backend(text:str):
    locked=re.search(r'constexpr\s+const\s+char\*\s+exe_hash\s*=\s*"([a-f0-9]{64})"',text)
    core_block=re.search(r'constexpr\s+Guard\s+guards\[\]\s*=\s*\{(.*?)\};',text,re.S)
    names_block=re.search(r'constexpr\s+const\s+char\*\s+hook_names\[\]\s*=\s*\{(.*?)\};',text,re.S)
    if not locked or not core_block or not names_block: raise ValueError('backend core inventory not recognized')
    core=re.findall(r'\{\s*(0x[0-9a-fA-F]+)\s*,\s*"([0-9a-fA-F]+)"\s*\}',core_block.group(1))
    names=re.findall(r'"([^"]+)"',names_block.group(1))
    if not core or len(core)!=len(names): raise ValueError(f'core guard/name count mismatch: guards={len(core)} names={len(names)}')
    sg=re.search(r'constexpr\s+Guard\s+smart_guard_guard\s*\{\s*(0x[0-9a-fA-F]+)\s*,\s*"([0-9a-fA-F]+)"\s*\}',text)
    if not sg: raise ValueError('optional smart_guard_guard not recognized')
    optional=[('smart_guard',sg.group(1),sg.group(2))]
    return locked.group(1),list(zip(names,core)),optional

def check_anchor(mm:Any,pe:PE,name:str,rva_text:str,guard:str)->dict:
    rva=int(rva_text,16);expected=bytes.fromhex(guard);off=pe.rva_to_file(rva,len(expected))
    actual=bytes(mm[off:off+len(expected)]).hex() if off is not None else None
    sec=pe.section_for_rva(rva);executable=bool(sec and (sec['flags']&0x20000000))
    return dict(name=name,rva=hex(rva),expected=guard,actual=actual,match=actual==guard,
                section=sec['name'] if sec else None,executable=executable)

def inventory(path:Path,backend:Path)->dict:
    text=backend.read_text(encoding='utf-8');locked,core_specs,optional_specs=parse_backend(text)
    if not path.is_file() or path.stat().st_size==0: raise ValueError('EXE missing or empty')
    with path.open('rb') as f,mmap.mmap(f.fileno(),0,access=mmap.ACCESS_READ) as mm:
        pe=PE(mm);sha=hashlib.sha256(mm).hexdigest()
        core=[check_anchor(mm,pe,name,rva,guard) for name,(rva,guard) in core_specs]
        optional=[check_anchor(mm,pe,name,rva,guard) for name,rva,guard in optional_specs]
        return dict(schema=2,exe_name=path.name,exe_sha256=sha,locked_sha256=locked,
            build_match=sha==locked,image_base=hex(pe.image_base),size_of_image=hex(pe.image_size),
            pe_timestamp=hex(pe.timestamp),sections=pe.sections,
            core_hook_count=len(core),optional_hook_count=len(optional),anchors=core,optional_anchors=optional,
            lua_name_candidates=[row for name in TOKENS for row in pe.occurrences(name)],
            classification='CURRENT_MAPPING_VERIFICATION_ONLY',exe_modified=False)

def main()->None:
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--exe',required=True,type=Path);ap.add_argument('--out',required=True,type=Path)
    ap.add_argument('--backend',type=Path,default=Path(__file__).resolve().parents[1]/'src/native_bridge/src/platform_windows.cpp')
    a=ap.parse_args();a.out.mkdir(parents=True,exist_ok=True);data=inventory(a.exe,a.backend)
    (a.out/'exe_inventory.json').write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    lines=['# BSC current mapping: tag<TAB>RVA.']
    lines += ['HOOK_'+r['name']+'\t'+r['rva'] for r in data['anchors'] if r['match'] and r['executable']]
    lines += ['OPTIONAL_'+r['name']+'\t'+r['rva'] for r in data['optional_anchors'] if r['match'] and r['executable']]
    lines += ['LUA_'+r['token']+'_'+r['encoding']+'\t'+r['rva'] for r in data['lua_name_candidates']]
    (a.out/'seeds.tsv').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    core_ok=all(r['match'] and r['executable'] for r in data['anchors'])
    optional_ok=all(r['match'] and r['executable'] for r in data['optional_anchors'])
    print(json.dumps({'build_match':data['build_match'],'core_hooks':f"{sum(r['match'] and r['executable'] for r in data['anchors'])}/{data['core_hook_count']}",
                      'optional_hooks':f"{sum(r['match'] and r['executable'] for r in data['optional_anchors'])}/{data['optional_hook_count']}",
                      'size_of_image':data['size_of_image'],'exe_modified':False}))
    if not data['build_match'] or not core_ok or not optional_ok:
        raise SystemExit('BUILD_MISMATCH: current mapping did not fully verify; do not run diagnostic bridge')
if __name__=='__main__': main()
