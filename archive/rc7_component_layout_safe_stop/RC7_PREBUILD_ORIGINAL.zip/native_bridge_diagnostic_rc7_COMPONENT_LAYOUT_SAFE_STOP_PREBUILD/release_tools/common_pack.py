"""Common release packaging infrastructure for Unified Native Bridge.
Deterministic PFH5 Mod pack I/O and self-contained DLL payload encoder.
"""
from __future__ import annotations
import hashlib, os, re, struct
from pathlib import Path

MINHOOK_SHA256 = "df452eacdb076c35a80c795df920fd3c6f128faa3e0bccb0b7490e95f8659d54"
UNIFIED_ABI_VERSION = "1.0.16-diagnostic-wh3-update-gated-rc7-component-layout-safe-stop"

def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def make_pack(files: list[tuple[str, bytes]]) -> bytes:
    index = bytearray()
    names = set()
    for name, raw in files:
        if name in names or '\x00' in name or name.startswith(('\\', '/')) or '..' in name.split('\\'):
            raise ValueError(f'Invalid or duplicate pack path: {name}')
        names.add(name)
        index += struct.pack('<IB', len(raw), 0) + name.encode('utf-8') + b'\0'
    return b'PFH5' + struct.pack('<6I', 3, 0, 0, len(files), len(index), 0) + bytes(index) + b''.join(raw for _, raw in files)

def parse_pack(data: bytes) -> dict[str, bytes]:
    if len(data) < 28 or data[:4] != b'PFH5':
        raise ValueError('Not a PFH5 file')
    flags, depcount, depsize, count, indexsize, mtime = struct.unpack_from('<6I', data, 4)
    if flags != 3 or depcount or depsize or count > 10000:
        raise ValueError('Not a supported simple PFH5 Mod pack')
    end = 28 + indexsize
    if end > len(data):
        raise ValueError('Invalid index size')
    i = 28
    entries = []
    for _ in range(count):
        if i + 5 > end:
            raise ValueError('Truncated index')
        size, flag = struct.unpack_from('<IB', data, i)
        i += 5
        z = data.find(b'\0', i, end)
        if z < 0 or flag:
            raise ValueError('Unsupported or invalid entry')
        name = data[i:z].decode('utf-8')
        i = z + 1
        entries.append((name, size))
    if i != end:
        raise ValueError('Index length mismatch')
    out = {}
    for name, size in entries:
        if name in out or i + size > len(data):
            raise ValueError('Bad payload')
        out[name] = data[i:i+size]
        i += size
    if i != len(data):
        raise ValueError('Trailing data in pack')
    return out

def encode_native_payload(data: bytes, label: str = 'native_payload') -> bytes:
    """Encodes arbitrary binary bytes into Lua table chunks."""
    rows = [
        f'-- Unified Native Bridge payload bytes: {label}',
        f'-- sha256={sha(data)}',
        f'-- size={len(data)}',
        'return table.concat({'
    ]
    for start in range(0, len(data), 4096):
        rows.append('"' + ''.join(f'\\{x:03d}' for x in data[start:start+4096]) + '",')
    return ('\n'.join(rows) + '\n})\n').encode('ascii')

def decode_payload(src: bytes) -> bytes:
    """Decodes Lua table chunks back to raw bytes."""
    text = src.decode('ascii')
    chunks = re.findall(r'"((?:\\\d{3})*)"', text)
    if not chunks:
        raise ValueError('Unsupported embedded payload encoding')
    raw = bytes(int(x) for chunk in chunks for x in re.findall(r'\\(\d{3})', chunk))
    return raw

def generate_bootstrap_lua(mod_name: str, bridge_bytes: bytes, minhook_bytes: bytes) -> str:
    """Generates the selfcontained_bootstrap materializer closure for a given mod."""
    minhook_hash = sha(minhook_bytes)
    bridge_hash = sha(bridge_bytes)
    bridge_size = len(bridge_bytes)

    return f"""-- Self-contained native materializer for {mod_name}.
local ensure_embedded_native=(function()
    local EMBEDDED_NATIVE = {{
        {{
            disk_path = ".\\\\minhook.x64.dll",
            virtual_path = "/script/{mod_name}/bin/minhook_Windows_NT-x64.lua",
            size = {len(minhook_bytes)},
            sha256 = "{minhook_hash}"
        }},
        {{
            disk_path = ".\\\\wh3_native_bridge.dll",
            virtual_path = "/script/{mod_name}/bin/bridge_Windows_NT-x64.lua",
            size = {bridge_size},
            sha256 = "{bridge_hash}"
        }}
    }}
    local function native_read_all(path)
        local f=io.open(path,"rb")
        if not f then return nil end
        local d=f:read("*a")
        f:close()
        return d
    end
    local function native_write_all(path,data)
        local f,err=io.open(path,"wb")
        if not f then return nil,err end
        local ok,werr=pcall(function() f:write(data) end)
        f:close()
        if not ok then return nil,werr end
        return true
    end
    local function native_payload(spec)
        if type(loadfile)~="function" then error("EMBED_LOADFILE_UNAVAILABLE") end
        local chunk,err=loadfile(spec.virtual_path)
        if type(chunk)~="function" then error("EMBED_PAYLOAD_OPEN "..tostring(err or spec.virtual_path)) end
        local ok,data=pcall(chunk)
        if not ok or type(data)~="string" then error("EMBED_PAYLOAD_DECODE "..tostring(data)) end
        if #data~=spec.size then error("EMBED_PAYLOAD_SIZE "..spec.disk_path.." got="..tostring(#data).." expected="..tostring(spec.size)) end
        return data
    end
    local function native_ensure_one(spec)
        local payload=native_payload(spec)
        local existing=native_read_all(spec.disk_path)
        if existing==payload then
            if type(dlog)=="function" then dlog("NATIVE_EMBED_KEEP file="..spec.disk_path.." size="..tostring(#payload).." sha256="..spec.sha256) end
            return true
        end
        if type(log)=="function" then log("NATIVE_EMBED_WRITE file="..spec.disk_path.." size="..tostring(#payload).." sha256="..spec.sha256) end
        local ok,err=native_write_all(spec.disk_path,payload)
        if not ok then error("EMBED_WRITE "..spec.disk_path.." "..tostring(err)) end
        local verify=native_read_all(spec.disk_path)
        if verify~=payload then error("EMBED_VERIFY_EXACT_BYTES "..spec.disk_path) end
        if type(log)=="function" then log("NATIVE_EMBED_OK file="..spec.disk_path.." exact_bytes=true sha256="..spec.sha256) end
        return true
    end
    return function()
        if type(io)~="table" or type(io.open)~="function" then error("EMBED_IO_UNAVAILABLE") end
        for i=1,#EMBEDDED_NATIVE do native_ensure_one(EMBEDDED_NATIVE[i]) end
    end
end)()
"""
