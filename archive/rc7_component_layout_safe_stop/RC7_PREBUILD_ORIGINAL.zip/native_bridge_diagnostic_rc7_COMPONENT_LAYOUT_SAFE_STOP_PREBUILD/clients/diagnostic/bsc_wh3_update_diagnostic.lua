-- BSC WH3 Update Compatibility Diagnostic Harness
-- Dedicated harness for Component Chain + two-stage Entity Alive runtime gates.
-- Diagnostic only: DOES NOT issue commands, arm BSC, take control, or enable Smart Guard.

local DIAG_VERSION = "1.0.16-diagnostic-wh3-update-gated-rc7-component-layout-safe-stop"
local SESSION_KEY = "WH3_UPDATE_GATE_DIAGNOSTIC"
local TAG = "[BSC_WH3_UPDATE_DIAGNOSTIC] "
local ROOT_TIMER_NAME = "bsc_wh3_root_discovery_poll"
local CASUALTY_TIMER_NAME = "bsc_wh3_casualty_poll"
local POLL_INTERVAL_MS = 500

local bmgr = nil
local bridge = nil

local function log(s)
    local line = TAG .. tostring(s)
    -- bm:out ultimately reaches the same script log as out(); do not emit twice.
    if bmgr and bmgr.out then pcall(function() bmgr:out(line) end)
    elseif out then out(line) end
end

local function clean(s)
    return (tostring(s):gsub("[%c%s]", "_"))
end

local BSC_HUGE = (type(math.huge) == "number" and math.huge) or 1e300
local function finite(n) return type(n) == "number" and n == n and n < BSC_HUGE and n > -BSC_HUGE end
local function valid_uid_string(v)
    return type(v) == "string" and #v > 0 and #v <= 10 and v ~= "0" and not v:find("[^0-9]")
        and (#v == 1 or v:sub(1,1) ~= "0") and (#v < 10 or v <= "4294967295")
end
local function unit_uid(unit)
    local ok, v = pcall(function() return unit:unique_ui_id() end)
    if not ok then return nil end
    if type(v) == "string" then return valid_uid_string(v) and v or nil end
    -- WH3 Lua numbers are float32: only this range is exact for integer IDs.
    if finite(v) and v > 0 and v <= 16777215 and v == math.floor(v) then return string.format("%.0f", v) end
    return nil
end

local S = {
    started = false,
    stopped = false,
    scheduled = false,
    epoch = nil,
    selected_unit = nil,
    selected_uid = nil,
    initial_men = 0,
    candidates = {},
    command_attempted = {},
    component_passed = false,
    deployment_passed = false,
    casualty_passed = false,
    all_passed = false,
    observer_attempted = false,
    observer_started = false,
    observer_stopped = false
}

local function end_session_if_needed()
    if not bridge or type(bridge.end_battle) ~= "function" or not S.epoch then return end
    local epoch = S.epoch
    local call_ok, ended, err = pcall(bridge.end_battle, epoch)
    if not call_ok then
        log("DIAG_SESSION_END result=FAIL epoch=" .. tostring(epoch) .. " call_error=" .. clean(ended))
        return
    end
    if ended ~= true then
        log("DIAG_SESSION_END result=FAIL epoch=" .. tostring(epoch) .. " error=" .. clean(err))
        return
    end
    S.epoch = nil
    log("DIAG_SESSION_END result=PASS epoch=" .. tostring(epoch))
end

local function stop_native_observer_if_needed()
    if not bridge or type(bridge.stop_observer) ~= "function" or S.observer_stopped then return true end
    if not S.observer_attempted then return true end
    local call_ok, stopped, err = pcall(bridge.stop_observer)
    if not call_ok then
        log("DIAG_OBSERVER_STOP result=FAIL call_error=" .. clean(stopped))
        return false
    end
    if stopped ~= true then
        log("DIAG_OBSERVER_STOP result=FAIL error=" .. clean(err))
        return false
    end
    S.observer_stopped = true
    S.observer_started = false
    log("DIAG_OBSERVER_STOP result=PASS hooks_disabled=true dll_pinned=true trampolines_resident=true")
    return true
end

local function stop_diagnostic(reason)
    if S.stopped then
        -- A later battle phase may give a previously failed end/disable call one
        -- more chance to close the session using the retained epoch/state.
        if S.epoch then end_session_if_needed() end
        if not S.observer_stopped then stop_native_observer_if_needed() end
        return
    end
    S.stopped = true
    log("DIAG_STOPPING reason=" .. tostring(reason))
    if bmgr then
        pcall(function() bmgr:remove_real_callback(ROOT_TIMER_NAME) end)
        pcall(function() bmgr:remove_real_callback(CASUALTY_TIMER_NAME) end)
    end
    end_session_if_needed()
    stop_native_observer_if_needed()
    log("DIAG_STOPPED reason=" .. tostring(reason))
end

local function fatal(reason, extra)
    local msg = "DIAG_ABORT reason=" .. tostring(reason)
    if extra ~= nil then msg = msg .. " detail=" .. clean(extra) end
    log(msg)
    stop_diagnostic(reason)
end

local function query_men(unit)
    local ok, men = pcall(function() return unit:number_of_men_alive() end)
    if not ok or not finite(men) or men < 0 or men > 300 or men ~= math.floor(men) then return nil, men end
    return men, nil
end

local function gate_status_log(prefix)
    local call_ok, st, err = pcall(bridge.diagnostic_gate_status)
    if not call_ok or type(st) ~= "table" then
        log(prefix .. " status_query=FAIL error=" .. clean(st or err))
        return false
    end
    local fully_gated =
        st.component_chain_gate == true and
        st.alive_deployment_passed == true and
        st.alive_casualty_passed == true and
        st.entity_alive_gate == true and
        tostring(st.component_gate_root) ~= "0" and
        tostring(st.component_gate_root) == tostring(st.alive_gate_root)
    log(prefix ..
        " component=" .. tostring(st.component_chain_gate) ..
        " component_root=" .. tostring(st.component_gate_root) ..
        " layout_method=" .. tostring(st.component_layout_method) ..
        " entity_component_offset=" .. tostring(st.entity_component_offset) ..
        " component_backref_offset=" .. tostring(st.component_backref_offset) ..
        " movement_state_offset=" .. tostring(st.movement_state_offset) ..
        " deployment=" .. tostring(st.alive_deployment_passed) ..
        " casualty=" .. tostring(st.alive_casualty_passed) ..
        " alive=" .. tostring(st.entity_alive_gate) ..
        " root=" .. tostring(st.alive_gate_root) ..
        " fully_gated=" .. tostring(fully_gated) ..
        " build_id=" .. tostring(st.build_id) ..
        " bridge_version=" .. tostring(st.bridge_version))
    return fully_gated
end

local function poll_tick()
    if S.stopped or not S.selected_unit or S.all_passed then return end

    local current_men, men_err = query_men(S.selected_unit)
    if current_men == nil then
        fatal("MEN_ALIVE_QUERY_FAILED", men_err)
        return
    end

    if current_men >= S.initial_men then return end

    log("DIAG_CASUALTY_DETECTED uid=" .. tostring(S.selected_uid) ..
        " initial=" .. tostring(S.initial_men) ..
        " current=" .. tostring(current_men) ..
        " loss=" .. tostring(S.initial_men - current_men))

    local call_ok, cas_res, api_err = pcall(
        bridge.diagnostic_probe_entity_alive,
        S.selected_uid,
        current_men
    )
    if not call_ok or type(cas_res) ~= "table" then
        fatal("CALL_ERROR_PROBE_CASUALTY", cas_res or api_err)
        return
    end

    log("DIAG_ALIVE_CASUALTY uid=" .. tostring(S.selected_uid) ..
        " phase=" .. tostring(cas_res.phase) ..
        " match=" .. tostring(cas_res.match) ..
        " slot_count=" .. tostring(cas_res.slot_count) ..
        " lua_men_alive=" .. tostring(cas_res.lua_men_alive) ..
        " native_alive_count=" .. tostring(cas_res.native_alive_count) ..
        " deployment_passed=" .. tostring(cas_res.deployment_passed) ..
        " casualty_passed=" .. tostring(cas_res.casualty_passed) ..
        " gate_passed=" .. tostring(cas_res.gate_passed) ..
        " reason=" .. tostring(cas_res.reason))

    local pass =
        cas_res.match == true and
        cas_res.phase == "CASUALTY" and
        cas_res.deployment_passed == true and
        cas_res.casualty_passed == true and
        cas_res.gate_passed == true

    if not pass then
        fatal("CASUALTY_GATE_FAIL", cas_res.reason)
        return
    end

    S.casualty_passed = true
    local fully_gated = gate_status_log("DIAG_STATUS")
    if not fully_gated then
        fatal("FINAL_GATE_STATUS_MISMATCH")
        return
    end

    S.all_passed = true
    log("DIAG_ALL_GATES_PASS")
    stop_diagnostic("ALL_GATES_PASSED_SUCCESSFULLY")
end

local function get_local_scriptunits()
    if not bmgr then return nil end
    local ok, res = pcall(function() return bmgr:get_scriptunits_for_local_players_army() end)
    if ok and res then return res end
    ok, res = pcall(function() return bmgr:get_scriptunits_for_local_players() end)
    if ok and res then return res end
    return nil
end

local function collect_candidate_units()
    local sunits = get_local_scriptunits()
    if not sunits then return {} end
    local count_ok, count = pcall(function() return sunits:count() end)
    if not count_ok or not finite(count) or count < 0 or count ~= math.floor(count) then return {} end
    local items = {}
    for i = 1, count do
        local su = nil
        pcall(function() su = sunits:item(i) end)
        if su and su.unit then
            local u = su.unit
            local uid = unit_uid(u)
            local men = query_men(u)
            if type(men) == "number" and men >= 20 and uid then
                items[#items + 1] = { unit=u, uid=uid, men=men }
            end
        end
    end
    table.sort(items, function(a,b) return a.men > b.men end)
    return items
end

local function log_bind_result(prefix, c, r)
    log(prefix .. " uid=" .. tostring(c.uid) ..
        " passed=" .. tostring(r.passed) ..
        " method=" .. tostring(r.method) ..
        " root=" .. tostring(r.root) ..
        " command_root_seen=" .. tostring(r.command_root_seen) ..
        " command_root=" .. tostring(r.command_root) ..
        " userdata_size=" .. tostring(r.userdata_size) ..
        " nodes_scanned=" .. tostring(r.nodes_scanned) ..
        " candidate_count=" .. tostring(r.candidate_count) ..
        " reason=" .. tostring(r.reason))
end

local function diagnostic_bind_candidate(c)
    local men, men_err = query_men(c.unit)
    if men == nil then return false, "MEN_ALIVE_QUERY_FAILED_" .. clean(men_err), nil end
    if men ~= c.men then return false, "DEPLOYMENT_COUNT_CHANGED", nil end
    local ok, r, err = pcall(bridge.diagnostic_bind_evidence_unit_v3, c.uid, c.unit, men)
    if not ok or type(r) ~= "table" then return false, "DISCOVERY_CALL_FAILED_" .. clean(r or err), nil end
    return r.passed == true, r.reason, r
end

local function begin_native_session()
    S.observer_attempted = true
    local obs_call_ok, obs_ok, obs_err = pcall(bridge.start_observer, true)
    if not obs_call_ok then return false, "OBSERVER_START_CALL_FAILED_" .. clean(obs_ok) end
    if obs_ok ~= true then return false, "OBSERVER_START_FAILED_" .. clean(obs_err) end
    S.observer_started = true

    local begin_call_ok, epoch, begin_err = pcall(bridge.begin_battle, SESSION_KEY)
    if not begin_call_ok then return false, "BEGIN_BATTLE_CALL_FAILED_" .. clean(epoch) end
    if type(epoch) ~= "string" or epoch == "" then return false, "BEGIN_BATTLE_FAILED_" .. clean(begin_err) end
    S.epoch = epoch
    log("DIAG_SESSION_BEGIN epoch=" .. tostring(epoch))
    return true, nil
end

local function join_layout_pairs(t)
    if type(t) ~= "table" then return "[]" end
    local parts = {}
    for i = 1, #t do
        local p = t[i]
        if type(p) == "table" then
            parts[#parts + 1] = tostring(p.entity_component_offset) .. ":" .. tostring(p.component_backref_offset)
        end
    end
    return "[" .. table.concat(parts, ",") .. "]"
end

local function join_offsets(t)
    if type(t) ~= "table" then return "[]" end
    local parts = {}
    for i = 1, #t do parts[#parts + 1] = tostring(t[i]) end
    return "[" .. table.concat(parts, ",") .. "]"
end

local function continue_after_bind(c, bind_res)
    S.selected_unit, S.selected_uid, S.initial_men = c.unit, c.uid, c.men
    log_bind_result("DIAG_UNIT_BOUND", c, bind_res)
    pcall(function() bmgr:remove_real_callback(ROOT_TIMER_NAME) end)

    local comp_call_ok, comp_res, comp_err = pcall(bridge.diagnostic_probe_component_chain, c.uid)
    if not comp_call_ok or type(comp_res) ~= "table" then fatal("CALL_ERROR_PROBE_COMPONENT", comp_res or comp_err); return end
    log("DIAG_COMPONENT uid=" .. tostring(c.uid) ..
        " passed=" .. tostring(comp_res.passed) ..
        " slot_count=" .. tostring(comp_res.slot_count) ..
        " sampled_count=" .. tostring(comp_res.sampled_count) ..
        " layout_method=" .. tostring(comp_res.layout_method) ..
        " entity_component_offset=" .. tostring(comp_res.entity_component_offset) ..
        " component_backref_offset=" .. tostring(comp_res.component_backref_offset) ..
        " movement_state_offset=" .. tostring(comp_res.movement_state_offset) ..
        " pair_candidates=" .. tostring(comp_res.layout_pair_candidate_count) ..
        " pair_report=" .. join_layout_pairs(comp_res.layout_pairs) ..
        " state_candidates=" .. tostring(comp_res.layout_state_candidate_count) ..
        " state_report=" .. join_offsets(comp_res.layout_state_offsets) ..
        " reason=" .. tostring(comp_res.reason))
    if comp_res.passed ~= true then fatal("COMPONENT_GATE_FAIL", comp_res.reason); return end
    if comp_res.slot_count ~= comp_res.sampled_count then fatal("COMPONENT_GATE_INCOMPLETE_SAMPLE", "slot=" .. tostring(comp_res.slot_count) .. " sampled=" .. tostring(comp_res.sampled_count)); return end
    S.component_passed = true

    local deployment_men, deployment_men_err = query_men(c.unit)
    if deployment_men == nil then fatal("MEN_ALIVE_QUERY_FAILED", deployment_men_err); return end
    if deployment_men ~= comp_res.slot_count then fatal("DEPLOYMENT_NOT_PRISTINE", "lua_men=" .. tostring(deployment_men) .. " slot_count=" .. tostring(comp_res.slot_count)); return end
    S.initial_men = deployment_men

    local dep_call_ok, dep_res, dep_err = pcall(bridge.diagnostic_probe_entity_alive, c.uid, deployment_men)
    if not dep_call_ok or type(dep_res) ~= "table" then fatal("CALL_ERROR_PROBE_DEPLOYMENT", dep_res or dep_err); return end
    log("DIAG_ALIVE_DEPLOYMENT uid=" .. tostring(c.uid) .. " phase=" .. tostring(dep_res.phase) .. " match=" .. tostring(dep_res.match) .. " slot_count=" .. tostring(dep_res.slot_count) .. " lua_men_alive=" .. tostring(dep_res.lua_men_alive) .. " native_alive_count=" .. tostring(dep_res.native_alive_count) .. " deployment_passed=" .. tostring(dep_res.deployment_passed) .. " casualty_passed=" .. tostring(dep_res.casualty_passed) .. " gate_passed=" .. tostring(dep_res.gate_passed) .. " reason=" .. tostring(dep_res.reason))
    local deployment_ok = dep_res.match == true and dep_res.phase == "DEPLOYMENT" and dep_res.deployment_passed == true and dep_res.casualty_passed == false and dep_res.gate_passed == false
    if not deployment_ok then fatal("DEPLOYMENT_GATE_FAIL", dep_res.reason); return end
    S.deployment_passed = true
    gate_status_log("DIAG_STATUS_AFTER_DEPLOYMENT")
    log("DIAG_WAITING_FOR_CASUALTY uid=" .. tostring(c.uid) .. " instruction=lose_at_least_one_model")
    local timer_call_ok, timer_err = pcall(function() bmgr:repeat_real_callback(poll_tick, POLL_INTERVAL_MS, CASUALTY_TIMER_NAME) end)
    if not timer_call_ok then fatal("TIMER_FAILED", timer_err); return end
end

local function root_discovery_tick()
    if S.stopped or S.selected_unit then return end
    for _, c in ipairs(S.candidates) do
        local ok, seen, root_or_err = pcall(bridge.diagnostic_command_root_v3, c.uid)
        if ok and seen == true and not S.command_attempted[c.uid] then
            S.command_attempted[c.uid] = true
            log("DIAG_COMMAND_ROOT_OBSERVED uid=" .. tostring(c.uid) .. " root=" .. tostring(root_or_err))
            local passed, reason, r = diagnostic_bind_candidate(c)
            if r then log_bind_result("DIAG_ROOT_DISCOVERY_AFTER_COMMAND", c, r) end
            if passed then continue_after_bind(c, r); return end
            log("DIAG_ROOT_DISCOVERY_MISS uid=" .. tostring(c.uid) .. " reason=" .. tostring(reason) .. " instruction=try_move_another_eligible_unit")
        end
    end
end

local function run_diagnostic()
    if S.started or S.stopped then return end
    S.started = true
    log("DIAG_STARTING")
    local session_ok, session_err = begin_native_session()
    if not session_ok then fatal("NATIVE_SESSION_START_FAILED", session_err); return end

    S.candidates = collect_candidate_units()
    if #S.candidates == 0 then fatal("NO_SUITABLE_INFANTRY_UNIT_FOUND", "require unit with >=20 living models"); return end
    log("DIAG_ROOT_DISCOVERY_BEGIN candidates=" .. tostring(#S.candidates))

    -- First try a bounded, read-only pointer graph rooted in each Lua userdata.
    -- Wrapper layout is shared across units; three independent userdata samples are
    -- enough for the bounded discovery attempt and avoid tens of thousands of RPM
    -- calls on large armies. Native command-root polling below covers every candidate.
    for i = 1, math.min(#S.candidates, 3) do
        local c = S.candidates[i]
        local passed, reason, r = diagnostic_bind_candidate(c)
        if r then log_bind_result("DIAG_ROOT_DISCOVERY_USERDATA", c, r) end
        if passed then continue_after_bind(c, r); return end
    end

    -- If CA's userdata no longer exposes the physical root through the bounded graph,
    -- wait for a real native MOVE/ATTACK/HALT observation. This does NOT assume the
    -- command root equals the physical root; it only unlocks an independent read-only
    -- command-root pointer graph scan.
    log("DIAG_WAITING_FOR_COMMAND_ROOT instruction=issue_one_normal_move_order_to_any_local_unit_with_20plus_models")
    local ok, err = pcall(function() bmgr:repeat_real_callback(root_discovery_tick, POLL_INTERVAL_MS, ROOT_TIMER_NAME) end)
    if not ok then fatal("ROOT_DISCOVERY_TIMER_FAILED", err); return end
end

local function boot()
    log("DIAG_BOOTING version=" .. DIAG_VERSION)
    if _VERSION ~= "Lua 5.1" then error("WRONG_LUA_VERSION " .. tostring(_VERSION)) end

    local ok_bm, b = pcall(function() return bm end)
    if not ok_bm or not b then error("BATTLE_MANAGER_UNAVAILABLE") end
    bmgr = b

    if type(package) ~= "table" or type(package.loadlib) ~= "function" then error("LOADLIB_UNAVAILABLE") end
    local lok, loader, le = pcall(package.loadlib, ".\\wh3_native_bridge.dll", "luaopen_wh3_native_bridge")
    if not lok or type(loader) ~= "function" then error("DLL_LOAD " .. clean(le or loader)) end
    local bok, module, be = pcall(loader)
    if not bok or type(module) ~= "table" then error("DLL_INIT " .. clean(be or module)) end
    bridge = module

    local v = bridge.version()
    if v ~= DIAG_VERSION then error("WRONG_BRIDGE_VERSION expected=" .. DIAG_VERSION .. " got=" .. tostring(v)) end
    log("BRIDGE_OK version=" .. tostring(v))

    for _, fn in ipairs({
        "start_observer", "stop_observer", "begin_battle", "end_battle",
        "diagnostic_command_root_v3",
        "diagnostic_bind_evidence_unit_v3",
        "diagnostic_probe_component_chain",
        "diagnostic_probe_entity_alive",
        "diagnostic_gate_status"
    }) do
        if type(bridge[fn]) ~= "function" then error("MISSING_DIAGNOSTIC_FUNCTION " .. fn) end
    end

    local function schedule()
        if S.scheduled or S.started or S.stopped then return end
        S.scheduled = true
        log("PHASE_CALLBACK Deployed")
        bmgr:callback(run_diagnostic, 500)
    end

    bmgr:register_phase_change_callback("Deployed", schedule)
    bmgr:register_phase_change_callback("VictoryCountdown", function() stop_diagnostic("VictoryCountdown") end)
    bmgr:register_phase_change_callback("Complete", function() stop_diagnostic("Complete") end)

    -- Quit-to-Windows can destroy battle UI before a normal phase callback fires.
    -- Disable native detours as soon as that button is clicked; cancelling the
    -- confirmation simply leaves this diagnostic stopped, which is safer than
    -- carrying allocator/free hooks into engine shutdown.
    local core_ok, core_obj = pcall(function() return core end)
    if core_ok and core_obj and type(core_obj.add_listener) == "function" then
        pcall(function()
            core_obj:add_listener(
                "BSC_RC7_SAFE_STOP_QUIT_WINDOWS",
                "ComponentLClickUp",
                function(context)
                    local ok, v = pcall(function() return context.string end)
                    if ok and v == "button_windows" then return true end
                    ok, v = pcall(function() return context:string() end)
                    return ok and v == "button_windows"
                end,
                function() stop_diagnostic("QUIT_WINDOWS_CLICK") end,
                true
            )
        end)
    end

    local phase_ok, current_phase = pcall(function() return bmgr:get_current_phase_name() end)
    log("DIAG_CURRENT_PHASE phase=" .. clean(phase_ok and current_phase or "UNKNOWN"))
    if phase_ok and current_phase == "Deployed" then schedule() end
end

local ok, err = pcall(boot)
if not ok then
    log("DIAG_BOOT_FAIL " .. tostring(err))
    stop_diagnostic("BOOT_FAIL")
end
