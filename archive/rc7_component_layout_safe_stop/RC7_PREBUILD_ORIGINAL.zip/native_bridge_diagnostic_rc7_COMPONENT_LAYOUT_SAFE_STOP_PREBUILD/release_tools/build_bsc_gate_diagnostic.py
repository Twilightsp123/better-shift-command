"""Builds dedicated BSC WH3 Update Gate Diagnostic Pack with embedded Native Bridge."""
from __future__ import annotations
import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "release_tools"))
from common_pack import (
    MINHOOK_SHA256,
    encode_native_payload,
    generate_bootstrap_lua,
    make_pack,
    parse_pack,
    decode_payload,
    sha,
)

DIAGNOSTIC_VERSION = "1.0.16-diagnostic-wh3-update-gated-rc7-component-layout-safe-stop"
BUILD_ID = "WH3_6C104A63AACC4D86_DIAGNOSTIC_RC7_COMPONENT_LAYOUT_SAFE_STOP"

if not __debug__:
    raise SystemExit("Diagnostic pack builder requires Python assertions; do not run with -O/-OO")

def build_diagnostic_pack(
    bridge_path: Path,
    script_path: Path,
    minhook_path: Path,
    license_path: Path,
    out_pack_path: Path
):
    print(f"=== BSC WH3 Update Gate Diagnostic Pack Builder ===")
    assert bridge_path.is_file(), f"Missing bridge DLL at {bridge_path}"
    assert script_path.is_file(), f"Missing diagnostic script at {script_path}"
    assert minhook_path.is_file(), f"Missing minhook DLL at {minhook_path}"
    assert license_path.is_file(), f"Missing license file at {license_path}"

    bridge_bytes = bridge_path.read_bytes()
    minhook_bytes = minhook_path.read_bytes()
    script_text = script_path.read_text(encoding="utf-8")
    license_bytes = license_path.read_bytes()

    # 1. Assertions on bridge binary
    assert sha(minhook_bytes) == MINHOOK_SHA256, "MinHook hash mismatch"
    assert DIAGNOSTIC_VERSION.encode("ascii") in bridge_bytes, f"Bridge missing version {DIAGNOSTIC_VERSION}"
    assert BUILD_ID.encode("ascii") in bridge_bytes, f"Bridge missing build ID {BUILD_ID}"

    # 2. Assertions on diagnostic script
    assert "smart_guard_enable" not in script_text, "Diagnostic must not enable smart guard"
    assert "arm_verified_issue(true)" not in script_text, "Diagnostic must not arm command issuance"
    assert "issue_verified_command" not in script_text, "Diagnostic must not issue commands"
    assert DIAGNOSTIC_VERSION in script_text, "Diagnostic script missing version string"
    assert "function boot()" in script_text or "local function boot()" in script_text, "Missing boot() function"
    # Harness/API contract guards: reject the exact stale field/argument patterns that previously slipped through CTest.
    for stale in (
        "comp_res.result", "comp_res.checked_count", "comp_res.valid_count",
        "dep_res.result", "cas_res.result",
        "st.component_chain_passed", "st.fully_gated",
        'end_battle("WH3_UPDATE_GATE_DIAGNOSTIC")',
        'uid = string.format("%.0f", id_val)',
        'S.epoch = nil\n    local call_ok, ended, err = pcall(bridge.end_battle, epoch)',
        'pcall(bridge.bind_evidence_unit_v3',
    ):
        assert stale not in script_text, f"Stale diagnostic harness contract token present: {stale}"
    for required in (
        "S.epoch", "end_battle, epoch",
        "comp_res.passed", "comp_res.sampled_count",
        "dep_res.lua_men_alive", "dep_res.native_alive_count",
        "cas_res.lua_men_alive", "cas_res.native_alive_count",
        "st.component_chain_gate", "st.component_gate_root", "st.entity_alive_gate",
        "current_men", "DEPLOYMENT_NOT_PRISTINE", "unit_uid",
        "diagnostic_command_root_v3", "diagnostic_bind_evidence_unit_v3",
        "DIAG_WAITING_FOR_COMMAND_ROOT",
        "stop_observer", "DIAG_OBSERVER_STOP", "QUIT_WINDOWS_CLICK",
        "layout_method", "pair_report=", "state_report=",
    ):
        assert required in script_text, f"Diagnostic harness missing required contract token: {required}"

    # 3. Inject self-contained bootstrap
    mod_name = "bsc_wh3_update_diagnostic"
    bootstrap_code = generate_bootstrap_lua(mod_name, bridge_bytes, minhook_bytes)

    target_needle = 'local lok, loader, le = pcall(package.loadlib, ".\\\\wh3_native_bridge.dll", "luaopen_wh3_native_bridge")'
    assert target_needle in script_text, f"Could not find loadlib needle in {script_path}"

    injected_text = script_text.replace(
        target_needle,
        f"ensure_embedded_native()\n    {target_needle}",
        1
    )
    injected_text = bootstrap_code + "\n" + injected_text

    # 4. Prepare pack entries
    bridge_payload = encode_native_payload(bridge_bytes, "wh3_native_bridge.dll")
    minhook_payload = encode_native_payload(minhook_bytes, "minhook.x64.dll")
    notices = f"BSC WH3 Update Gate Diagnostic. Native Bridge ABI {DIAGNOSTIC_VERSION}; frozen MinHook runtime. Diagnostic test only.\n".encode("utf-8")

    entries = [
        (rf"script\battle\mod\{mod_name}.lua", injected_text.encode("utf-8")),
        (rf"script\{mod_name}\bin\bridge_Windows_NT-x64.lua", bridge_payload),
        (rf"script\{mod_name}\bin\minhook_Windows_NT-x64.lua", minhook_payload),
        (rf"script\{mod_name}\licenses\MINHOOK_LICENSE.txt", license_bytes),
        (rf"script\{mod_name}\licenses\THIRD_PARTY_NOTICES.txt", notices),
    ]

    pack_bytes = make_pack(entries)
    out_pack_path.parent.mkdir(parents=True, exist_ok=True)
    out_pack_path.write_bytes(pack_bytes)

    # 5. Self-verifying unpack
    parsed = parse_pack(out_pack_path.read_bytes())
    assert len(parsed) == 5, f"Expected 5 entries, got {len(parsed)}"
    dec_bridge = decode_payload(parsed[rf"script\{mod_name}\bin\bridge_Windows_NT-x64.lua"])
    dec_minhook = decode_payload(parsed[rf"script\{mod_name}\bin\minhook_Windows_NT-x64.lua"])
    assert sha(dec_bridge) == sha(bridge_bytes), "Decoded bridge SHA256 mismatch!"
    assert sha(dec_minhook) == MINHOOK_SHA256, "Decoded MinHook SHA256 mismatch!"

    print(f"[OK] Diagnostic Pack created successfully: {out_pack_path}")
    print(f"     Pack Size:       {len(pack_bytes):,} bytes | SHA256: {sha(pack_bytes)}")
    print(f"     Bridge SHA256:   {sha(bridge_bytes)}")
    print(f"     MinHook SHA256:  {sha(minhook_bytes)}")
    print(f"     Script Entries:  {len(parsed)}")

    # Return info for report generation
    return {
        "pack_path": str(out_pack_path),
        "pack_size": len(pack_bytes),
        "pack_sha256": sha(pack_bytes),
        "bridge_sha256": sha(bridge_bytes),
        "minhook_sha256": sha(minhook_bytes),
        "entries": list(parsed.keys())
    }

def main():
    if sys.flags.optimize:
        raise RuntimeError("Do not run diagnostic pack builder with python -O; safety assertions must remain enabled")
    parser = argparse.ArgumentParser(description="Build BSC WH3 Update Gate Diagnostic Pack")
    parser.add_argument("--bridge", default=str(ROOT / "build_diag/Release/wh3_native_bridge.dll"))
    parser.add_argument("--script", default=str(ROOT / "clients/diagnostic/bsc_wh3_update_diagnostic.lua"))
    parser.add_argument("--minhook", default=str(ROOT / "baseline/minhook.x64.dll"))
    parser.add_argument("--license", default=str(ROOT / "baseline/MINHOOK_LICENSE.txt"))
    parser.add_argument("--out", default=str(ROOT / "output/diagnostic/zzz_bsc_wh3_update_gate_diagnostic.pack"))

    args = parser.parse_args()
    build_diagnostic_pack(
        Path(args.bridge),
        Path(args.script),
        Path(args.minhook),
        Path(args.license),
        Path(args.out)
    )

if __name__ == "__main__":
    main()
