#!/usr/bin/env python3
"""RC7 prebuild contract checker. No EXE access and no source mutation."""
from __future__ import annotations
from pathlib import Path
import importlib.util, re, sys
ROOT=Path(__file__).resolve().parents[1]
VER='1.0.16-diagnostic-wh3-update-gated-rc7-component-layout-safe-stop'
BUILD='WH3_6C104A63AACC4D86_DIAGNOSTIC_RC7_COMPONENT_LAYOUT_SAFE_STOP'
EXE_SHA='6c104a63aacc4d865f78e6d198185f830a43255ae18367ad6be906f5f3433297'

EXPECTED_CORE = {
    'move':('0x030344d4','488bc4488958104889701848897820554154415541564157488da888feffff48'),
    'attack':('0x03032854','488bc448895808488968104889701857415641574883ec30498b18488bf1488b'),
    'allocator':('0x02f5248c','48895c240855488d6c24c04881ec40010000488bd984d2752083b9102d000000'),
    'halt':('0x0301b890','48895c24084889742410574883ec20488bf18ada4881c188020000e88007f2ff'),
    'lua_move':('0x02ed5808','488bc44889580848897018488978205541564157488d68d84881ec1001000048'),
    'lua_attack':('0x02ed50a0','48895c240848896c2410488974241857415641574881ecd0000000458af8488b'),
    'publish_move':('0x01cb1dc8','48895c2418574883ec408b0524c53b02488bd9488d4c245089442450488bfae8'),
    'publish_attack':('0x02df28bc','48895c2418574883ec408b0504b92701488bd9488d4c245089442450488bfae8'),
    'writer_begin':('0x01bce174','48895c24084c8bda488bd94c89590833d2668911418b8300500000894110418b'),
    'writer_finalize':('0x01bd140c','8039004c8bc9753180790100752b488b51088b4114440fb7820050000066442b'),
    'copy':('0x01baf488','488bc44889581048897018574883ec20488bfa4c8d40088b920050000033db88'),
    'stage':('0x01bb0c94','48895c24084889742410574883ec20488bd98bf2488b4918498bf8e830330000'),
    'move_handler':('0x02ecf0e0','48895c241048897c242055488d6c24a94881ec00010000488bfa488bd9488bd1'),
    'attack_handler':('0x02ecebac','488bc448895810555657488d68a84881ec40010000488bf20f2970d8488bd148'),
    'selection':('0x02f042d4','40555356574157488d6c24c94881ecc00000004533ff4c8d456f488bda44897d'),
    'free':('0x0052f770','4883ec584885c90f8412010000f6054caaa30302'),
    'contact_pair':('0x030a3859','488b47184885c07418488b88e8020000'),
}
EXPECTED_OPTIONAL = {'smart_guard':('0x030e2524','48895c24084889742410574883ec20488b02488bf1488bca418af8488bdaff90')}

def need(cond,msg):
    if not cond: raise SystemExit('PREBUILD_CONTRACT_FAIL: '+msg)

def text(rel): return (ROOT/rel).read_text(encoding='utf-8')

pw=text('src/native_bridge/src/platform_windows.cpp')
bh=text('src/native_bridge/src/bridge_host.cpp')
ev=text('src/native_bridge/src/evidence_probe.cpp')
cl=text('src/native_bridge/src/component_layout.cpp')
hdr=text('src/native_bridge/include/wh3/bridge_host.hpp')
lua=text('clients/diagnostic/bsc_wh3_update_diagnostic.lua')
builder=text('release_tools/build_bsc_gate_diagnostic.py')
common=text('release_tools/common_pack.py')
inspect_path=ROOT/'tools/inspect_exe.py'

# Exact build lock and version identity.
need(EXE_SHA in pw,'new WH3 SHA lock missing')
for name,blob in [('header',hdr),('harness',lua),('builder',builder)]: need(VER in blob,f'{name} diagnostic version mismatch')
need(BUILD in pw and BUILD in builder,'diagnostic build id mismatch')
need(VER in common,'common pack ABI label stale')

# Frozen VTables / Move payload semantics.
for blob_name,blob in [('BridgeHost',bh),('EvidenceProbe',ev)]:
    need('0x0390E248' in blob and '0x03910228' in blob,f'{blob_name} VTable mapping stale')
need('kPayload+0x08' in ev,'Move Z must be payload +0x08')
need('kPayload+0x10,&z' not in ev,'stale Move Z orientation offset remains')

# Pre-gate root resolver must not call entity_snapshot/alive. The shared
# readonly helper may live outside the strict resolver body.
m=re.search(r'Result<std::uintptr_t> BridgeHost::resolve_evidence_userdata.*?\n}',bh,re.S)
need(m is not None,'resolve_evidence_userdata not found')
resolver=m.group(0)
need('readonly_evidence_root_valid' in bh,'pre-gate readonly resolver missing')
need('evidence_probe_.entity_snapshot(' not in resolver,'pre-gate resolver still calls entity_snapshot')
helper=re.search(r'bool BridgeHost::readonly_evidence_root_valid.*?\n}',bh,re.S)
need(helper is not None and '0x88' in helper.group(0) and '0x90' in helper.group(0),'pre-gate position validation missing')


# RC6+ root discovery must not collapse command and evidence roots.
need('diagnostic_bind_evidence' in bh,'root-discovery diagnostic evidence resolver missing')
need('COMMAND_ROOT_DIRECT' in bh and 'COMMAND_ROOT_GRAPH' in bh,'command-root read-only graph fallback missing')
need('expected_count' in bh,'expected soldier-count discriminator missing')
need('diagnostic_command_root_v3' in text('src/native_bridge/src/lua_module.cpp'),'command-root diagnostic Lua export missing')
need('diagnostic_bind_evidence_unit_v3' in text('src/native_bridge/src/lua_module.cpp'),'root-discovery Lua export missing')
need('DIAG_WAITING_FOR_COMMAND_ROOT' in lua,'harness command-root fallback missing')
need('pcall(bridge.bind_evidence_unit_v3' not in lua,'diagnostic harness must not call stale strict userdata binder')


# RC7 component-layout discovery must remain bounded, read-only, unique-candidate and fail-closed.
for token in [
    'scan_component_layout', 'COMPONENT_LAYOUT_PAIR_NOT_FOUND', 'COMPONENT_LAYOUT_PAIR_AMBIGUOUS',
    'MOVEMENT_STATE_CANDIDATE_AMBIGUOUS', 'ENTITY_VTABLE_OR_ALIVE_SLOT_INVALID',
    'g_entity_component_offset', 'g_component_backref_offset', 'g_movement_state_offset',
    'DISCOVERED_PAIR_LEGACY_STATE', 'DISCOVERED_PAIR_DISCOVERED_STATE'
]:
    need(token in pw or token in cl,f'RC7 component-layout safety token missing: {token}')
need('for (std::size_t entity_off = 0; entity_off < kEntityScanEnd' in cl,'RC7 bounded entity-offset scan missing')
need('kEntityScanEnd = 0x200' in cl and 'kComponentScanEnd = 0xC00' in cl,'RC7 layout scan bounds drifted')
need('state_valid(0x8B0, true)' in cl,'RC7 discovered legacy-state preference must require live non-zero evidence')
need('layout_pair_candidate_count' in text('src/native_bridge/src/lua_module.cpp'),'RC7 layout candidate diagnostics not exported')
need('pair_report=' in lua and 'state_report=' in lua,'RC7 layout candidate diagnostics not logged')

# RC7 observer safe-stop: disable detours but keep DLL/backend/trampolines resident.
for token in ['MH_QueueDisableHook','platform_stop_observer','g_mh.queue_disable(nullptr)','OK_STOPPED']:
    need(token in pw or token in hdr,f'RC7 observer safe-stop token missing: {token}')
stop_body=re.search(r'const char\* platform_stop_observer\(\).*?\n}',pw,re.S)
need(stop_body is not None,'platform_stop_observer body missing')
need('FreeLibrary' not in stop_body.group(0) and 'MH_Uninitialize' not in stop_body.group(0),'safe stop must not unload native code')
need('remove(' not in stop_body.group(0),'safe stop must not remove/free trampolines')
lua_module=text('src/native_bridge/src/lua_module.cpp')
need('REG("stop_observer",stop_observer)' in lua_module,'stop_observer Lua export missing')
for token in ['DIAG_OBSERVER_STOP','QUIT_WINDOWS_CLICK','button_windows','stop_native_observer_if_needed']:
    need(token in lua,f'RC7 harness safe-stop token missing: {token}')

# Runtime gate safety / root identity.
need('g_component_gate_root' in pw,'component gate root identity missing')
need('COMPONENT_ROOT_MISMATCH' in pw,'alive gate root mismatch guard missing')
need('platform_reset_diagnostic_gates();' in pw,'diagnostic reset missing')
need('DIAGNOSTIC_RUNTIME_GATES_NOT_READY' in bh,'begin_issue gate recheck missing')
need('PAGE_GUARD' in pw and 'PAGE_NOACCESS' in pw,'VirtualQuery guard protections missing')
need('LUA_MEN_ALIVE_RANGE_0_TO_300' in text('src/native_bridge/src/lua_module.cpp'),'Lua alive count range validation missing')

# Harness lifecycle / pristine deployment / no issuing.
for token in ['S.epoch','end_battle, epoch','DEPLOYMENT_NOT_PRISTINE','component_gate_root','unit_uid']:
    need(token in lua,f'harness missing {token}')
for token in ['issue_verified_command','arm_verified_issue(true)','smart_guard_enable']:
    need(token not in lua,f'diagnostic harness contains forbidden command path {token}')

# Current source hook inventory must parse dynamically and match frozen map names/RVAs.
spec=importlib.util.spec_from_file_location('inspect_exe_rc4',inspect_path)
mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
locked,core,opt=mod.parse_backend(pw)
need(locked==EXE_SHA,'inspect parser locked hash mismatch')
need(len(core)>0 and len(core)==len(EXPECTED_CORE),'current diagnostic core hook inventory count mismatch')
need(len(opt)==len(EXPECTED_OPTIONAL),'optional hook inventory count mismatch')
for name,(rva,guard) in core:
    need(name in EXPECTED_CORE,f'unexpected core hook {name}')
    er,eguard=EXPECTED_CORE[name]
    need(rva.lower()==er,f'{name} RVA drifted: {rva} != {er}')
    need(guard.lower()==eguard,f'{name} guard bytes drifted')
for name,rva,guard in opt:
    need(name in EXPECTED_OPTIONAL,f'unexpected optional hook {name}')
    er,eguard=EXPECTED_OPTIONAL[name]
    need(rva.lower()==er,f'{name} optional RVA drifted: {rva} != {er}')
    need(guard.lower()==eguard,f'{name} optional guard bytes drifted')
need(core[-1][0]=='contact_pair','contact_pair must remain core index 16')
need('constexpr bool g_wh3_smart_guard_staged_disabled = true;' in pw,'Smart Guard must remain staged disabled for the core diagnostic')

print(f'PREBUILD_CONTRACT_PASS core_hooks={len(core)} optional_hooks={len(opt)} version={VER}')
